import importlib.util
import io
from pathlib import Path
import unittest
from contextlib import redirect_stdout,redirect_stderr
from unittest.mock import patch

p=Path(__file__).resolve().parents[1]/'downloads/tinkerbytetech-ubuntu-gaming-setup-terminal.py'
spec=importlib.util.spec_from_file_location('terminal',p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class TerminalTests(unittest.TestCase):
    def test_numbered_selection(self):
        self.assertEqual(m.terminal_choices('1 2 3 5'),['steam','lutris','faugus','wine'])
        self.assertEqual(m.terminal_choices(''),['steam','lutris','faugus'])
        self.assertEqual(m.terminal_choices('1,1,3'),['steam','faugus'])
    def test_bad_choices(self):
        for answer in ['0','8','1; rm','steam']:
            with self.assertRaises(ValueError):m.terminal_choices(answer)
    def test_cli_dry_run_never_calls_commands(self):
        with patch.object(m.TerminalSetup,'command',side_effect=AssertionError('Executed!')) as command,redirect_stdout(io.StringIO()) as output:
            code=m.terminal_main(['--dry-run','--select','steam,wine'])
        self.assertEqual(code,0);command.assert_not_called();self.assertIn('No packages',output.getvalue())
    def test_interactive_menu_defaults_to_preview(self):
        with patch.object(m.sys.stdin,'isatty',return_value=True),patch('builtins.input',side_effect=['1 2 3 5','','']),patch.object(m.TerminalSetup,'command',side_effect=AssertionError('Executed!')) as command,redirect_stdout(io.StringIO()) as output:
            code=m.terminal_main([])
        self.assertEqual(code,0);command.assert_not_called();self.assertIn('Choose what to install',output.getvalue())
    def test_cli_flatpak_choice(self):
        with patch.object(m.TerminalSetup,'command',side_effect=AssertionError('Executed!')) as command,redirect_stdout(io.StringIO()) as output:
            code=m.terminal_main(['--dry-run','--select','steam','--mode','flatpak'])
        self.assertEqual(code,0);command.assert_not_called()
        self.assertIn('Installation format: flatpak',output.getvalue())
        self.assertIn('flatpak --user install',output.getvalue())

    def test_wrong_distro_install_refused(self):
        with patch.object(m,'read_os_release',return_value={'ID':'pika','PRETTY_NAME':'PikaOS'}),patch.object(m.TerminalSetup,'command',side_effect=AssertionError('Executed!')) as command,redirect_stdout(io.StringIO()),redirect_stderr(io.StringIO()):
            code=m.terminal_main(['--yes','--select','steam'])
        self.assertEqual(code,2);command.assert_not_called()
    def test_cancel_menu(self):
        with patch.object(m.sys.stdin,'isatty',return_value=True),patch('builtins.input',return_value='q'),redirect_stdout(io.StringIO()):
            self.assertEqual(m.terminal_main([]),0)

if __name__=='__main__':unittest.main()
