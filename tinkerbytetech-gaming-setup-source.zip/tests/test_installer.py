import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import http.client
import json
import threading
import time
from http.server import ThreadingHTTPServer

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('installer',ROOT/'source/installer.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class PlanTests(unittest.TestCase):
    def test_distribution_checks(self):
        for target, osid in [('debian','debian'),('ubuntu','ubuntu'),('kubuntu','ubuntu'),('fedora','fedora')]:
            self.assertEqual(m.compatible(target,{'ID':osid},'x86_64'),'')
            self.assertTrue(m.compatible(target,{'ID':'pika'},'x86_64'))
        self.assertTrue(m.compatible('fedora',{'ID':'fedora'},'aarch64'))
        self.assertTrue(m.compatible('fedora',{'ID':'fedora'},'x86_64',True))

    def test_each_launchers_plan_uses_user_flatpak(self):
        for target in m.DISTROS:
            plan=m.build_plan(target,['steam','lutris','faugus'])
            apps=[s for s in plan if s['app']]
            self.assertEqual(len(apps),3)
            self.assertTrue(all(s['argv'][1]=='--user' and not s['admin'] for s in apps))
            self.assertTrue(all('sudo' not in s['argv'] for s in plan))
            self.assertFalse(any('i386' in s['argv'] for s in plan))

    def test_native_wine_routes(self):
        for target in ['debian','ubuntu','kubuntu']:
            plan=m.build_plan(target,['wine'])
            self.assertEqual(plan[0]['argv'],['dpkg','--add-architecture','i386'])
            self.assertIn('wine32:i386',plan[-1]['argv'])
            self.assertFalse(any(s['app'] for s in plan))
        plan=m.build_plan('fedora',['wine'])
        self.assertEqual(plan[0]['argv'],['dnf','-y','install','wine'])

    def test_invalid_selection_rejected(self):
        for values in [[],None,'steam',['steam;rm -rf /'],['--uninstall'],[{}],['steam']*8]:
            with self.assertRaises(ValueError):m.build_plan('ubuntu',values)

    def test_duplicates_collapsed(self):
        self.assertEqual(m.build_plan('ubuntu',['steam','steam']),m.build_plan('ubuntu',['steam']))

    def test_os_release_is_data(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'os-release';p.write_text('ID=ubuntu\nPRETTY_NAME="Ubuntu Linux"\nBAD="$(touch /tmp/dont-run-this)"\n')
            info=m.read_os_release(p)
            self.assertEqual(info['PRETTY_NAME'],'Ubuntu Linux')
            self.assertEqual(info['BAD'],'$(touch /tmp/dont-run-this)')

    def test_demo_cannot_execute(self):
        setup=m.Setup('ubuntu',True)
        with patch.object(setup,'command',side_effect=AssertionError('Executed!')):
            choices=['steam'];steps=m.build_plan('ubuntu',choices)
            setup.start(choices,m.plan_id(choices,steps),False)
            while setup.snapshot()['running']:time.sleep(.01)
        self.assertFalse(setup.failed)
        self.assertIn('No packages',setup.message)

    def test_wrong_distro_real_install_blocked(self):
        setup=m.Setup('ubuntu');setup.blocked='Wrong distro'
        with self.assertRaises(ValueError):setup.start(['steam'],m.plan_id(['steam'],m.build_plan('ubuntu',['steam'])),False)
        self.assertFalse(setup.running)

    def test_plan_confirmation_required(self):
        setup=m.Setup('ubuntu',True)
        with self.assertRaises(ValueError):setup.start(['steam'],'stale',True)

    def test_stop_on_first_failure(self):
        setup=m.Setup('ubuntu',True)
        with patch.object(setup,'command',side_effect=RuntimeError('Package failed')) as cmd:
            setup.run(m.build_plan('ubuntu',['steam']),False)
        self.assertEqual(cmd.call_count,1)
        self.assertTrue(setup.failed)
        self.assertIn('Package failed',setup.message)
        self.assertFalse(setup.running)

    def test_installed_app_is_preserved(self):
        setup=m.Setup('ubuntu',True)
        with patch.object(m.shutil,'which',return_value='/usr/bin/flatpak'),patch.object(m.subprocess,'run') as run,patch.object(m.subprocess,'Popen') as spawn:
            run.return_value.returncode=0
            setup.command(next(s for s in m.build_plan('ubuntu',['steam']) if s['app']))
            spawn.assert_not_called()

    def test_unrelated_remote_refused(self):
        setup=m.Setup('ubuntu',True)
        step=next(s for s in m.build_plan('ubuntu',['steam']) if 'remote-add' in s['argv'])
        with patch.object(m.shutil,'which',return_value='/usr/bin/flatpak'),patch.object(m.subprocess,'run') as run,patch.object(m.subprocess,'Popen') as spawn:
            run.return_value.returncode=0;run.return_value.stdout='flathub\thttps://unrelated.example/repo\n'
            with self.assertRaises(RuntimeError):setup.command(step)
            spawn.assert_not_called()

class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.setup=m.Setup('ubuntu',True)
        self.server=ThreadingHTTPServer(('127.0.0.1',0),m.make_handler(self.setup))
        self.setup.origin=f'http://127.0.0.1:{self.server.server_port}'
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join()
    def request(self,path,body=None,token=True,origin=True,host=None):
        connection=http.client.HTTPConnection('127.0.0.1',self.server.server_port)
        headers={}
        if token:headers['X-Setup-Token']=self.setup.token
        if origin:headers['Origin']=self.setup.origin
        if host:headers['Host']=host
        data=json.dumps(body) if body is not None else None
        connection.request('POST' if body is not None else 'GET',path,data,headers)
        response=connection.getresponse();code=response.status;payload=response.read();connection.close();return code,payload
    def test_missing_token(self):self.assertEqual(self.request('/api/info',token=False)[0],403)
    def test_wrong_host(self):self.assertEqual(self.request('/api/info',host='attacker.example')[0],403)
    def test_missing_origin(self):self.assertEqual(self.request('/api/plan',{'choices':['steam']},origin=False)[0],403)
    def test_plan_route(self):
        code,body=self.request('/api/plan',{'choices':['steam']});self.assertEqual(code,200);self.assertEqual(len(json.loads(body)['steps']),4)
    def test_command_injection_rejected(self):self.assertEqual(self.request('/api/plan',{'choices':['steam; echo bad']})[0],400)
    def test_demo_info(self):
        code,body=self.request('/api/info');info=json.loads(body);self.assertTrue(info['demo']);self.assertEqual(info['blocked'],'')

if __name__=='__main__':unittest.main()
