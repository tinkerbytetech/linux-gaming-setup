# Original terminal interface, combined with our common planner by build.py.
import sys
from datetime import datetime

class TerminalSetup(Setup):
    def __init__(self, target, dry=False):
        super().__init__(target, dry)
        self.authorization = 'sudo'

    def append(self, message):
        super().append(message)
        print(message, flush=True)

    def command(self, step):
        if step['admin']:
            sudo = shutil.which('sudo', path='/usr/bin:/bin')
            if not sudo:
                raise RuntimeError('Install sudo through your distribution before running setup.')
            result = subprocess.run([sudo, '-v'])
            if result.returncode:
                raise RuntimeError('Administrator authentication was cancelled or refused.')
        super().command(step)


def terminal_choices(answer):
    numbers = list(APPS) + list(NATIVE)
    words = answer.replace(',', ' ').split()
    if not words:
        return ['steam', 'lutris', 'faugus']
    choices = []
    for word in words:
        if word.isdigit() and 1 <= int(word) <= len(numbers):
            choices.append(numbers[int(word)-1])
        else:
            raise ValueError('Choose tool numbers 1 through 7, separated by spaces.')
    return validate_choices(choices)


def terminal_main(argv=None):
    parser = argparse.ArgumentParser(description='TinkerByteTech '+DISTROS.get(TARGET,'Linux')+' interactive gaming setup')
    parser.add_argument('--dry-run', action='store_true', help='Print the setup without installing anything')
    parser.add_argument('--select', help='Comma-separated tool names, e.g. steam,lutris,faugus,wine')
    parser.add_argument('--yes', action='store_true', help='Install the reviewed command-line selection without the final prompt')
    args = parser.parse_args(argv)
    setup = TerminalSetup(TARGET, args.dry_run)
    print('\nTinkerByteTech | '+DISTROS[TARGET]+' Gaming Setup\n'+'─'*52)
    print('Detected: '+setup.info.get('PRETTY_NAME','Linux'))
    print('Tools: Steam · Lutris · Faugus Launcher · Wine\n')
    if args.select:
        try:
            choices = validate_choices([v.strip() for v in args.select.split(',')])
        except ValueError as exc:
            parser.error(str(exc))
    elif args.dry_run and not sys.stdin.isatty():
        choices = ['steam', 'lutris', 'faugus']
    else:
        if not sys.stdin.isatty():
            parser.error('Use --select with --dry-run or --yes when running without an interactive terminal.')
        print('Choose what to install:\n')
        for index, key in enumerate(list(APPS) + list(NATIVE), 1):
            name = APPS[key][0] if key in APPS else NATIVE[key]
            description = APPS[key][2] if key in APPS else 'Optional distribution package'
            print(f'  {index}. {name:<18} {description}')
        print('\nDefault: 1 2 3 (Steam, Lutris and Faugus)')
        while True:
            try:
                answer = input('Tool numbers, or Q to exit [1 2 3]: ').strip()
                if answer.lower() == 'q':
                    print('Setup cancelled.');return 0
                choices = terminal_choices(answer)
                break
            except ValueError as exc:
                print(str(exc))
            except (EOFError, KeyboardInterrupt):
                print('\nSetup cancelled.');return 0
    steps = build_plan(TARGET, choices)
    print('\nYOUR SETUP\n'+'─'*52)
    for index, step in enumerate(steps, 1):
        print(f'{index}. {step["title"]}')
        print('   '+('sudo ' if step['admin'] else '')+shlex.join(step['argv']))
    dry = args.dry_run
    if not dry and not args.yes:
        if not sys.stdin.isatty():
            parser.error('Use an interactive terminal, --dry-run, or --yes.')
        try:
            answer = input('\n[I] Install  [P] Preview  [Q] Quit [P]: ').strip().lower()
        except (EOFError, KeyboardInterrupt):
            print('\nSetup cancelled.');return 0
        if answer in ('', 'p'):
            dry = True
        elif answer != 'i':
            print('Setup cancelled.');return 0
    if setup.blocked and not dry:
        print('\n'+setup.blocked, file=sys.stderr);return 2
    if os.geteuid() == 0 and not dry:
        print('\nRun this script as your regular user, without sudo. It requests administrator access for individual system steps.',file=sys.stderr);return 2
    setup.demo = dry
    setup.start(choices, plan_id(choices,steps), dry)
    while setup.snapshot()['running']:
        try:
            time.sleep(.1)
        except KeyboardInterrupt:
            print('\nA setup step is running. Allow it to finish before closing the terminal.',flush=True)
    print('\n'+setup.message)
    if not dry:
        log_dir = Path.home()/'.local/state/tinkerbytetech/gaming-setup'
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            log_path = log_dir/(datetime.now().strftime('%Y%m%d-%H%M%S')+'.log')
            log_path.write_text('\n'.join(setup.log)+'\n')
            print('Log: '+str(log_path))
        except OSError as exc:
            print('Could not save log: '+str(exc),file=sys.stderr)
    return 1 if setup.failed else 0

if __name__ == '__main__':
    raise SystemExit(terminal_main())
