#!/usr/bin/env python3
"""Build four standalone downloads from our original shared implementation."""
from pathlib import Path
import hashlib
import py_compile
import zipfile
ROOT = Path(__file__).resolve().parent
source = (ROOT/'source/installer.py').read_text()
terminal = source[:source.index('PAGE = r')] + source[source.index('class Setup:'):source.index('def make_handler(')] + (ROOT/'source/terminal.py').read_text()
checksums=[]
for target in ('debian','ubuntu','kubuntu','fedora'):
    output=ROOT/'downloads'/f'tinkerbytetech-{target}-gaming-setup.py'
    output.write_text(source.replace("TARGET = '__TARGET__'",f"TARGET = '{target}'"))
    py_compile.compile(str(output), doraise=True)
    checksums.append(hashlib.sha256(output.read_bytes()).hexdigest()+'  '+output.name)
    archive=output.with_suffix('.zip')
    instructions=(f'TinkerByteTech {target.title()} Gaming Setup 0.1.0\n\n'
                  f'Extract this archive and run: python3 {output.name}\n'
                  'Run as your regular desktop user, without sudo. Python 3.9+ is required.\n'
                  'The graphical page opens locally in your browser. Choose tools, review the steps, and run the preview.\n'
                  'To install, turn off Preview only, review again, and select Install selected tools.\n'
                  'For interface-only mode: add --demo to the command.\n'
                  'System-package authentication uses pkexec and your desktop polkit agent.\n')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(output,output.name)
        z.writestr('START-HERE.txt',instructions)
    checksums.append(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name)
for target in ('debian','ubuntu','kubuntu','fedora'):
    output=ROOT/'downloads'/f'tinkerbytetech-{target}-gaming-setup-terminal.py'
    output.write_text(terminal.replace("TARGET = '__TARGET__'",f"TARGET = '{target}'"))
    py_compile.compile(str(output), doraise=True)
    archive=output.with_suffix('.zip')
    instructions=(f'TinkerByteTech {target.title()} interactive terminal installer\n\n'
                  f'Run: python3 {output.name}\n'
                  'Select tool numbers, review the plan, then choose Install or Preview.\n'
                  'Run as your regular user, without sudo. Administrator steps request sudo authentication.\n'
                  f'Preview example: python3 {output.name} --dry-run --select steam,lutris,faugus,wine\n')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(output,output.name)
        z.writestr('START-HERE.txt',instructions)
    for item in (output,archive):
        checksums.append(hashlib.sha256(item.read_bytes()).hexdigest()+'  '+item.name)
(ROOT/'downloads/SHA256SUMS').write_text('\n'.join(checksums)+'\n')
print('Built four terminal installers and four optional graphical installers.')
